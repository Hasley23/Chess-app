package com.esause.chess;

import java.util.ArrayList;

class AI {
    private Player aiPlayer;
    private Player realPlayer;
    private vec bestMove = new vec(new pos(0,0), new pos(0,0));
    private int INFINITY = 30000;    // player's pieces count
    private int DEPTH = 4;        // MiniMax depth

    // PAWN
    private int[][] pawnFalse = {{0, 0, 0, 0, 0, 0, 0, 0},
                                {50, 50, 50, 50, 50, 50, 50, 50},
                                {10, 10, 20, 30, 30, 20, 10, 10},
                                {5, 5, 10, 25, 25, 10, 5, 5},
                                {0, 0, 0, 20, 20, 0, 0, 0},
                                {5, -5, -10, 0, 0, -10, -5, 5},
                                {5, 10, 10, -20, -20, 10, 10, 5},
                                {0, 0, 0, 0, 0, 0, 0, 0}};

    private int[][] pawnTrue = {{5, 10, 10, -20, -20, 10, 10, 5},
                                {50, 50, 50, 50, 50, 50, 50, 50},
                                {5, -5, -10, 0, 0, -10, -5, 5},
                                {0, 0, 0, 20, 20, 0, 0, 0},
                                {5, 5, 10, 25, 25, 10, 5, 5},
                                {10, 10, 20, 30, 30, 20, 10, 10},
                                {50, 50, 50, 50, 50, 50, 50, 50},
                                {0, 0, 0, 0, 0, 0, 0, 0}};

    // KNIGHT
    private int[][] knightFalse = {{-50, -40, -30, -30, -30, -30, -40, -50},
                                  {-40, -20, 0, 0, 0, 0, -20, -40},
                                  {-30, 0, 10, 15, 15, 10, 0, -30},
                                  {-30, 5, 15, 20, 20, 15, 5, -30},
                                  {-30, 0, 15, 20, 20, 15, 0, -30},
                                  {-30, 5, 10, 15, 15, 10, 5, -30},
                                  {-40, -20, 0, 5, 5, 0, -20, -40},
                                  {-50, -40, -30, -30, -30, -30, -40, -50}};

    private int[][] knightTrue = {{-50, -40, -30, -30, -30, -30, -40, -50},
                                 {-40, -20, 0, 5, 5, 0, -20, -40},
                                 {-30, 5, 10, 15, 15, 10, 5, -30},
                                 {-30, 0, 15, 20, 20, 15, 0, -30},
                                 {-30, 5, 15, 20, 20, 15, 5, -30},
                                 {-30, 0, 10, 15, 15, 10, 0, -30},
                                 {-40, -20, 0, 0, 0, 0, -20, -40},
                                 {-50, -40, -30, -30, -30, -30, -40, -50}};

    // BISHOP
    private int[][] bishopFalse = {{-20,-10,-10,-10,-10,-10,-10,-20},
                                  {-10,  0,  0,  0,  0,  0,  0,-10},
                                  {-10,  0,  5, 10, 10,  5,  0,-10},
                                  {-10,  5,  5, 10, 10,  5,  5,-10},
                                  {-10,  0, 10, 10, 10, 10,  0,-10},
                                  {-10, 10, 10, 10, 10, 10, 10,-10},
                                  {-10,  5,  0,  0,  0,  0,  5,-10},
                                  {-20,-10,-10,-10,-10,-10,-10,-20}};

    private int[][] bishopTrue = {{-20,-10,-10,-10,-10,-10,-10,-20},
                                 {-10,  5,  0,  0,  0,  0,  5,-10},
                                 {-10, 10, 10, 10, 10, 10, 10,-10},
                                 {-10,  0, 10, 10, 10, 10,  0,-10},
                                 {-10,  5,  5, 10, 10,  5,  5,-10},
                                 {-10,  0,  5, 10, 10,  5,  0,-10},
                                 {-10,  0,  0,  0,  0,  0,  0,-10},
                                 {-20,-10,-10,-10,-10,-10,-10,-20}};

    // ROOK
    private int[][] rookFalse = {{0,  0,  0,  0,  0,  0,  0,  0},
                                {5, 10, 10, 10, 10, 10, 10,  5},
                                {-5,  0,  0,  0,  0,  0,  0, -5},
                                {-5,  0,  0,  0,  0,  0,  0, -5},
                                {-5,  0,  0,  0,  0,  0,  0, -5},
                                {-5,  0,  0,  0,  0,  0,  0, -5},
                                {-5,  0,  0,  0,  0,  0,  0, -5},
                                {0,  0,  0,  5,  5,  0,  0,  0}};

    private int[][] rookTrue = {{0,  0,  0,  5,  5,  0,  0,  0},
                               {-5,  0,  0,  0,  0,  0,  0, -5},
                               {-5,  0,  0,  0,  0,  0,  0, -5},
                               {-5,  0,  0,  0,  0,  0,  0, -5},
                               {-5,  0,  0,  0,  0,  0,  0, -5},
                               {-5,  0,  0,  0,  0,  0,  0, -5},
                               {5, 10, 10, 10, 10, 10, 10,  5},
                               {0,  0,  0,  0,  0,  0,  0,  0}};

    // QUEEN
    private int[][] queenFalse = {{-20,-10,-10, -5, -5,-10,-10,-20},
                                 {-10,  0,  0,  0,  0,  0,  0,-10},
                                 {-10,  0,  5,  5,  5,  5,  0,-10},
                                 {-5,  0,  5,  5,  5,  5,  0, -5},
                                 {0,  0,  5,  5,  5,  5,  0, -5},
                                 {-10,  5,  5,  5,  5,  5,  0,-10},
                                 {-10,  0,  5,  0,  0,  0,  0,-10},
                                 {-20,-10,-10, -5, -5,-10,-10,-20}};

    private int[][] queenTrue = {{-20,-10,-10, -5, -5,-10,-10,-20},
                                 {-10,  0,  5,  0,  0,  0,  0,-10},
                                 {-10,  5,  5,  5,  5,  5,  0,-10},
                                 {0,  0,  5,  5,  5,  5,  0, -5},
                                 {-5,  0,  5,  5,  5,  5,  0, -5},
                                 {-10,  0,  5,  5,  5,  5,  0,-10},
                                 {-10,  0,  0,  0,  0,  0,  0,-10},
                                 {-20,-10,-10, -5, -5,-10,-10,-20}};

    // KING START
    private int[][] kingFalse = {{-30,-40,-40,-50,-50,-40,-40,-30},
                                 {-30,-40,-40,-50,-50,-40,-40,-30},
                                 {-30,-40,-40,-50,-50,-40,-40,-30},
                                 {-30,-40,-40,-50,-50,-40,-40,-30},
                                 {-20,-30,-30,-40,-40,-30,-30,-20},
                                 {-10,-20,-20,-20,-20,-20,-20,-10},
                                 {20, 20,  0,  0,  0,  0, 20, 20},
                                 {20, 30, 10,  0,  0, 10, 30, 20}};

    private int[][] kingTrue = {{20, 30, 10,  0,  0, 10, 30, 20},
                               {20, 20,  0,  0,  0,  0, 20, 20},
                               {-10,-20,-20,-20,-20,-20,-20,-10},
                               {-20,-30,-30,-40,-40,-30,-30,-20},
                               {-30,-40,-40,-50,-50,-40,-40,-30},
                               {-30,-40,-40,-50,-50,-40,-40,-30},
                               {-30,-40,-40,-50,-50,-40,-40,-30},
                               {-30,-40,-40,-50,-50,-40,-40,-30}};

    // KING END
    private int[][] king2False = {{-50,-40,-30,-20,-20,-30,-40,-50},
                                 {-30,-20,-10,  0,  0,-10,-20,-30},
                                 {-30,-10, 20, 30, 30, 20,-10,-30},
                                 {-30,-10, 30, 40, 40, 30,-10,-30},
                                 {-30,-10, 30, 40, 40, 30,-10,-30},
                                 {-30,-10, 20, 30, 30, 20,-10,-30},
                                 {-30,-30,  0,  0,  0,  0,-30,-30},
                                 {-50,-30,-30,-30,-30,-30,-30,-50}};

    private int[][] king2True = {{-50,-30,-30,-30,-30,-30,-30,-50},
                                {-30,-30,  0,  0,  0,  0,-30,-30},
                                {-30,-10, 20, 30, 30, 20,-10,-30},
                                {-30,-10, 30, 40, 40, 30,-10,-30},
                                {-30,-10, 30, 40, 40, 30,-10,-30},
                                {-30,-10, 20, 30, 30, 20,-10,-30},
                                {-30,-20,-10,  0,  0,-10,-20,-30},
                                {-50,-40,-30,-20,-20,-30,-40,-50}};


    AI(Player aiPlayer, Player realPlayer) {
        this.aiPlayer = aiPlayer;
        this.realPlayer = realPlayer;
    }

    vec calculateAiMove(Board board, boolean isCheckStatus) {
        Player fPlayerAI = new Player(aiPlayer.getIsHuman(), aiPlayer.getDirection(), aiPlayer.getColor());
        Player fPlayerREAL = new Player(realPlayer.getIsHuman(), realPlayer.getDirection(), realPlayer.getColor());
        if (!isCheckStatus) {
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (board.getFigures()[i][j].getColor() == aiPlayer.getColor()) {
                        ArrayList<vec> f = board.generateMovesForAi(new pos(i, j), aiPlayer);
                        if (f.size() == 1 && board.getFigures()[f.get(0).getS().getY()][f.get(0).getS().getX()].getFigure() == FigureType.KING) {
                            return f.get(0);
                        }
                    }
                }
            }

            Board temp = copyBoard(board);
            DecisionTree tree = generateDecisionTree(temp, fPlayerAI, fPlayerREAL, null, DEPTH);
            alphaBetaPruning(-INFINITY, INFINITY, DEPTH, tree);
        } else {
            // STALEMATE
            ArrayList<pos> possibleMovePoints = new ArrayList<>();
            for (int i = 0; i < 8; i++) {
                for (int j = 0; j < 8; j++) {
                    if (board.getFigures()[i][j].getColor() == aiPlayer.getColor()) {
                        possibleMovePoints.add(new pos(i, j));
                    }
                }
            }

            for (pos p : possibleMovePoints) {
                ArrayList<pos> tempos = board.findAnyMoves(p, aiPlayer);
                for (pos tp : tempos) {
                    Board tempBoard = new Board(board.getFigures());
                    tempBoard.makeMove(new vec(p, tp), aiPlayer);
                    if (tempBoard.checkRules(realPlayer) != GameStatus.CHECK) {
                        return new vec(p, tp);
                    }
                }
            }

            bestMove = null;
        }

        return bestMove;
    }

    private DecisionTree generateDecisionTree (Board board,
                                               Player player, Player player2,
                                               vec curMove,
                                               int depth) {

        //if (depth == 0 || board.getMoveCounter() == 50 || board.getKingDied()) return new DecisionTree(curMove, board.evaluate(player.getColor()));

        if (depth == 0 || board.getMoveCounter() == 50 || board.getKingDied()) return new DecisionTree(curMove, Evaluate(board, player));

        ArrayList<vec> moves = board.getAllMovesForPlayer(player);

        DecisionTree Tree = new DecisionTree(curMove, Evaluate(board, player));

        //DecisionTree Tree = new DecisionTree(curMove, board.evaluate(player.getColor()));



        for (vec move : moves) {

            Board temp = new Board(board.getFigures(), board.getMoveCounter(), board.getKingDied());

            /*
            // Save move
            Figure[] lastMoveFigures = new Figure[2];

            lastMoveFigures[0] = new Figure(board.getFigures()[move.getF().getY()][move.getF().getX()].getColor(),
                    board.getFigures()[move.getF().getY()][move.getF().getX()].getFigure());

            lastMoveFigures[1] = new Figure(board.getFigures()[move.getS().getY()][move.getS().getX()].getColor(),
                    board.getFigures()[move.getS().getY()][move.getS().getX()].getFigure());
            */



            // Make move
            temp.makeMoveWithoutCheck(move);

            // Recursion
            Tree.addChild(generateDecisionTree(temp, player2, player, move, depth-1));


            // Undo move
            //board.getFigures()[move.getF().getY()][move.getF().getX()] = new Figure(lastMoveFigures[0].getColor(), lastMoveFigures[0].getFigure());
            //board.getFigures()[move.getS().getY()][move.getS().getX()] = new Figure(lastMoveFigures[1].getColor(), lastMoveFigures[1].getFigure());
        }

        return Tree;
    }

    /**
     * Alpha-Beta pruning implementation
     * Use this before generateDecisionTree()
     * @param alpha first maximum
     * @param beta second maximum
     * @param depth MiniMax depth
     * @param decisionTree current tree node
     * @return best score
     */
    private int alphaBetaPruning(int alpha, int beta, int depth, DecisionTree decisionTree){
        if (depth == 0) return decisionTree.getNodeScore();
        int score = -INFINITY;

        if (depth == DEPTH){
            bestMove = decisionTree.getChild().getMove();
        }

        for (DecisionTree child : decisionTree.getChildren()) {
            int temp = alphaBetaPruning(-beta, -alpha, depth - 1, child);

            if (temp > score) {
                if (depth == DEPTH){
                    bestMove = child.getMove();
                }
                score = temp;
            }
            if (score > alpha) {
                alpha = score;
            }
            if (alpha >= beta) {
                break;
            }
        }

        decisionTree.setNodeScore(score);
        return score;
    }

    /**
     * @return new same as input Board object
     */
    private Board copyBoard(Board board) {
        return new Board(board.getFigures(), board.getMoveCounter(), board.getKingDied());
    }

    private int Evaluate(Board board, Player player) {
        int trueScore = 0;
        int falseScore = 0;

        pos kingPosTrue = null;
        pos kingPosFalse = null;
        boolean isTrueQueenHere = false;
        boolean isFalseQueenHere = false;

        int additionalTruePieces = 0;
        int additionalFalsePieces = 0;

        for (int i = 0; i < 8; i++) {
            for (int j = 0; j < 8; j++) {
                FigureType ft = board.getFigures()[i][j].getFigure();
                if (ft != FigureType.NONE) {
                    int tempScore = 0;
                    if (player.getDirection() && board.getFigures()[i][j].getColor() == player.getColor()) {
                        switch (ft) {
                            case PAWN:
                                tempScore = pawnTrue[i][j];
                                additionalTruePieces++;
                                break;
                            case KNIGHT:
                                tempScore = knightTrue[i][j];
                                additionalTruePieces++;
                                break;
                            case BISHOP:
                                tempScore = bishopTrue[i][j];
                                additionalTruePieces++;
                                break;
                            case ROOK:
                                tempScore = rookTrue[i][j];
                                additionalTruePieces++;
                                break;
                            case QUEEN:
                                isTrueQueenHere = true;
                                tempScore = queenTrue[i][j];
                                break;
                            case KING:
                                kingPosTrue = new pos(i, j);
                                break;
                        }

                        trueScore += tempScore;
                    } else {
                        switch (ft) {
                            case PAWN:
                                tempScore = pawnFalse[i][j];
                                additionalFalsePieces++;
                                break;
                            case KNIGHT:
                                tempScore = knightFalse[i][j];
                                additionalFalsePieces++;
                                break;
                            case BISHOP:
                                tempScore = bishopFalse[i][j];
                                additionalFalsePieces++;
                                break;
                            case ROOK:
                                tempScore = rookFalse[i][j];
                                additionalFalsePieces++;
                                break;
                            case QUEEN:
                                isFalseQueenHere = true;
                                tempScore = queenFalse[i][j];
                                break;
                            case KING:
                                kingPosFalse = new pos(i, j);
                                break;
                        }

                        falseScore += tempScore;
                    }
                }
            }
        }

        if (kingPosTrue == null) {
            if (player.getDirection()) {
                return -INFINITY;
            } else {
                return INFINITY;
            }
        }

        if (kingPosFalse == null) {
            if (player.getDirection()) {
                return INFINITY;
            } else {
                return -INFINITY;
            }
        }

        if (!isFalseQueenHere && !isTrueQueenHere ||
                isTrueQueenHere && additionalTruePieces < 2 ||
                isFalseQueenHere && additionalFalsePieces < 2) {
            trueScore += king2True[kingPosTrue.getY()][kingPosTrue.getX()];
            falseScore += king2False[kingPosFalse.getY()][kingPosFalse.getX()];
        } else {
            trueScore += kingTrue[kingPosTrue.getY()][kingPosTrue.getX()];
            falseScore += kingFalse[kingPosFalse.getY()][kingPosFalse.getX()];
        }

        if (player.getDirection()) {
            return trueScore - falseScore;
        } else {
            return falseScore - trueScore;
        }
    }
}
